## Ordina Python Test
*By Jeroen Beekman*

This project contains the solutions to the 3 exercises in "application_test.pdf".

You can run the tests by installing pytest 

`pip install pytest==7.1.2`

and running 

`python -m pytest .`

I included a pip freeze in `requirements.txt`, but other than pytest this is all just from the black[d] linting package.
